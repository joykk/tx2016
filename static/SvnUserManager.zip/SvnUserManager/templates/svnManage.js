/**
 * Created by xiaobai on 16/8/24.
 */
function pass(event, type) {
    if (type == 1)
    {
        type = "project";
        var id = $(event.target).parent().prev().prev().prev().prev().prev().text()
    }
    if (type == 2)
    {
        type = "account";
        var id = $(event.target).parent().prev().prev().prev().text()
    }
    $.ajax({
       url: "/cgi-bin/app.py/manage?apply=pass&type=" + type + "&id="+id,
       success: function(msg) {
           alert("成功");
           location.reload();
       },
       error: function(request) {
            alert("提交失败");
       }
    })
    }
function refuse(event, type) {
    if (type == 1)
    {
        type = "project";
        var id = $(event.target).parent().prev().prev().prev().prev().prev().text()
    }
    if (type == 2)
    {
        type = "account";
        var id = $(event.target).parent().prev().prev().prev().text()
    }
    $.ajax({
       url: "/cgi-bin/app.py/manage?apply=refuse&type=" + type + "&id="+id,
       success: function(msg) {
           alert("成功");
           location.reload();
       },
       error: function(request) {
            alert("提交失败");
       }
    })
}