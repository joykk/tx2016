#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sqlite3


def create_db():
    db = sqlite3.connect("/Users/xiaobai/PycharmProjects/SvnUserManager/cgi-bin/svn.db")
    cursor = db.cursor()
    create_table_sql = "CREATE TABLE project_apply (" \
                       "id INTEGER PRIMARY KEY NOT NULL," \
                       "apply_time DATETIME DEFAULT (datetime(CURRENT_TIMESTAMP,'localtime'))," \
                       "rtx_name CHAR(48)," \
                       "project CHAR(100)," \
                       "premission CHAR(10)," \
                       "status INT DEFAULT 1);"
    cursor.execute(create_table_sql)
    db.commit()

    create_table_sql = "CREATE TABLE account_apply (" \
                       "id INTEGER PRIMARY KEY NOT NULL," \
                       "apply_time DATETIME DEFAULT (datetime(CURRENT_TIMESTAMP,'localtime'))," \
                       "rtx_name CHAR(48)," \
                       "password CHAR(100)," \
                       "status INT DEFAULT 1);"

    cursor.execute(create_table_sql)
    db.commit()

    db.close()

if __name__ == "__main__":
    create_db()
