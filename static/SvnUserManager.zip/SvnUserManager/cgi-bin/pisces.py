#!/usr/bin/env python
# -*- coding: utf-8 -*-
from wsgiref import handlers
import functools
import threading
import re


# class Router(object):
#     def __init__(self):
#         self.rules = []
#         self.static = {}
def _local_property():
    ls = threading.local()

    def fget(_):
        try:
            return ls.var
        except AttributeError:
            raise RuntimeError("Request context not initialized.")

    def fset(_, value):
        ls.var = value

    def fdel(_):
        del ls.var

    return property(fget, fset, fdel, 'Thread-local property')


class DictProperty(object):
    def __init__(self, attr, key=None, read_only=False):
        self.attr, self.key, self.read_only = attr, key, read_only

    def __call__(self, func):
        functools.update_wrapper(self, func, updated=[])
        self.getter, self.key = func, self.key or func.__name__
        return self

    def __get__(self, obj, cls):
        if obj is None: return self
        key, storage = self.key, getattr(obj, self.attr)
        if key not in storage: storage[key] = self.getter(obj)
        return storage[key]

    def __set__(self, obj, value):
        if self.read_only: raise AttributeError("Read-Only property.")
        getattr(obj, self.attr)[self.key] = value

    def __delete__(self, obj):
        if self.read_only: raise AttributeError("Read-Only property.")
        del getattr(obj, self.attr)[self.key]


class BaseRequest(object):
    def __init__(self, environ=None):
        self.environ = {} if environ is None else environ
        self.environ['bottle.request'] = self

    @property
    def path(self):
        return '/' + self.environ.get('PATH_INFO', '').lstrip('/')

    @property
    def method(self):
        return self.environ.get('REQUEST_METHOD', 'GET').upper()

    def url_args(self):
        raise RuntimeError('This request is not connected to a route.')

    def get_header(self, name, default=None):
        """ Return the value of a request header, or a given default value. """
        return self.headers.get(name, default)


class BaseResponse(object):
    def __init__(self):
        pass


class BottleException(Exception):
    pass


class HTTPResponse(BaseResponse, BottleException):
    def __init__(self, body='', status=None, headers=None, **more_headers):
        super(HTTPResponse, self).__init__(body, status, headers, **more_headers)

    def apply(self, other):
        other._status_code = self._status_code
        other._status_line = self._status_line
        other._headers = self._headers
        other._cookies = self._cookies
        other.body = self.body


class HTTPError(HTTPResponse):
    default_status = 500

    def __init__(self,
                 status=None,
                 body=None,
                 exception=None,
                 traceback=None, **more_headers):
        self.exception = exception
        self.traceback = traceback
        super(HTTPError, self).__init__(body, status, **more_headers)


class LocalRequest(BaseRequest):
    bind = BaseRequest.__init__
    environ = _local_property()


class LocalResponse(BaseResponse):
    bind = BaseResponse.__init__


class Route(object):
    def __init__(self, app, path, method, handler, name=None,):
        self.app = app
        self.rule = path
        self.method = method
        self.handler = handler
        self.name = name or None
        # self._re_route = re.compile(r'(\:[a-zA-Z_]\w*)')


class Pisces(object):
    def __init__(self):
        self.router = {}

    def route(self, path=None, method="GET", handler=None, name=None, apply=None, skip=None, **config):
        if callable(path):
            path, handler = None, path

        def decorator(handler):
            self.router[path] = handler
            return handler
        return decorator(handler) if handler else decorator

    def _handle(self, environ):
        path = environ['bottle.raw_path'] = environ['PATH_INFO']
        out = None
        environ['bottle.app'] = self
        request.bind(environ)
        route_handle = self.router[path]

        return route_handle()

    def wsgi(self, environ, start_response):
        request.bind(environ)
        response.bind()
        out = self._handle(environ)
        start_response('200 OK', [('Content-Type', 'text/html')])
        return [out]

    def __call__(self, environ, start_response):
        return self.wsgi(environ, start_response)

    def run(self):
        handlers.CGIHandler().run(self.wsgi)

request = LocalRequest()
response = LocalResponse()