#!/usr/bin/env python
# -*- coding: utf-8 -*-
import cgi, cgitb
import os
import sqlite3
import json
from utils import db_path, get_rtx_name, render_template
from config import config
import Cookie
from session import Session
from wsgiref.handlers import CGIHandler

cgitb.enable()
form = cgi.FieldStorage()
type = form.getvalue("type")
ticket = form.getvalue("ticket")
client_ip = cgi.escape(os.environ["REMOTE_ADDR"])

if type == "account":
    password = form.getvalue("password")

    db = sqlite3.connect(db_path)
    sql = 'INSERT INTO account_apply (rtx_name, password, status) VALUES ("{}", "{}", {});'.format(rtx_name, password, 1)
    try:
        db.execute(sql)
        db.commit()
    except sqlite3.IntegrityError:
        return_code = 1
    db.close()
    exit()

if type == "project":
    project = form.getvalue("path")
    permission = ""
    if form.getvalue('readable'):
        permission += "r"

    if form.getvalue('writeable'):
        permission += "w"

    db = sqlite3.connect(db_path)
    sql = 'INSERT INTO project_apply (rtx_name, project, premission, status)' \
          ' VALUES ("{}", "{}", "{}", {});'.format(rtx_name, project, permission, 1)
    db.execute(sql)
    db.commit()
    db.close()
    exit()

if type == "getName":
    print "Content-type:text/html"
    print

    print get_rtx_name()
    exit()

if 'HTTP_COOKIE' in os.environ:
    cookie_string=os.environ.get('HTTP_COOKIE')
    c=Cookie.SimpleCookie()
    c.load(cookie_string)

    try:
        data=c['ticket']
    except:
        pass

    render_template("apply.html")
    exit()

if ticket:
    client_ip = cgi.escape(os.environ["REMOTE_ADDR"])
    rtx_name = get_rtx_name(ticket, client_ip)
    session = Session(ticket[:10])
    session["rtx"] = rtx_name

    print "Content-type:text/html"
    print 'Set-Cookie: ticket={}'.format(ticket)
    print

    print "<script>window.location =\"http://10.68.100.102/cgi-bin/apply.py\"</script>"
    exit()

else:
    url = "http://{}/cgi-bin/apply.py".format(config["ip"])
    login_url = "http://passport.oa.com/modules/passport/signin.ashx?url={}".format(url)

    print "HTTP/1.1 303 See Other"
    print "Content-type:text/html"
    print "Location: {}".format(login_url)
    print

    print "<script>window.location =\"{}\"</script>".format(login_url)
    exit()