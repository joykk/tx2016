#!/usr/bin/env python
# -*- coding: utf-8 -*-


config = {
    "ip": "10.68.100.102",
    "svnconf_path": "/Users/xiaobai/tmp/conf",
    "template_path": "/Users/xiaobai/PycharmProjects/SvnUserManager/templates/"
}