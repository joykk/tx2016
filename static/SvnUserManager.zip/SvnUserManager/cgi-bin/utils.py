#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os.path
import ConfigParser
import json
import sqlite3

from config import config
from tof_web_api_demo import get_user_info

auth_file = os.path.join(config["svnconf_path"], "authz")
passwd_file = os.path.join(config["svnconf_path"], "passwd")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db_path = "/Users/xiaobai/PycharmProjects/SvnUserManager/cgi-bin/svn.db"


def get_rtx_name(ticket, client_ip):
    res = get_user_info(ticket, client_ip)
    info_dict = json.loads(res)
    if info_dict["Ret"] == 0:
        return info_dict["Data"]["LoginName"]
    else:
        return info_dict


def render_template(template_name):
    print "Content-type:text/html"
    print

    template_name = config["template_path"] + template_name
    with open(template_name, "r") as html:
        for line in html.readlines():
            print line


def apply_account(username, password):
    passwd_cf = ConfigParser.ConfigParser()
    passwd_cf.read(passwd_file)

    try:
        passwd_cf.set("users", username, password)
        with open(passwd_file,"w+") as f:
            passwd_cf.write(f)
    except:
        return False
    return True


def apply_project(project, username, premission):
    auth_cf = ConfigParser.ConfigParser()
    auth_cf.read(auth_file)

    try:
        auth_cf.set(project, username, premission)
        with open(auth_file, "w+") as f:
            auth_cf.write(f)
    except Exception, e:
        print e
        return False
    return True
