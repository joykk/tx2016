#!/usr/bin/env python
# -*- coding: utf-8 -*-

import cgi
import json
import sqlite3
from utils import db_path, apply_account, apply_project, render_template


form = cgi.FieldStorage()
response = {"content": []}

apply = form.getvalue("apply")
type = form.getvalue("type")



if apply is None and type is None:
    render_template("manage.html")
    exit()


if type == "getProjectApplyList":
    with sqlite3.connect(db_path) as db:
        sql = 'SELECT * FROM project_apply WHERE STATUS = 1;'
        res = db.execute(sql)
        for row in res:
            row_dict = {"id": row[0], "apply_time": row[1], "rtx_name": row[2], "project": row[3], "premission": row[4]}
            response["content"].append(row_dict)

if type == "getAccountApplyList":
    with sqlite3.connect(db_path) as db:
        sql = 'SELECT * FROM account_apply WHERE STATUS = 1;'
        res = db.execute(sql)
        for row in res:
            row_dict = {"id": row[0], "apply_time": row[1], "rtx_name": row[2]}
            response["content"].append(row_dict)

if type == "project":
    table = "project_apply"
elif type == "account":
    table = "account_apply"

if apply == "pass":
    apply_id = form.getvalue("id")
    with sqlite3.connect(db_path) as db:
        sql = 'SELECT * FROM {} WHERE id = {};'.format(table, apply_id)
        res = db.execute(sql).fetchone()
        if type == "project":
            res = apply_project(res[3], res[2], res[4])
        elif type == "account":
            res = apply_account(res[2], res[3])
        if res is True:
            sql = 'UPDATE {} SET status = 0 WHERE id = {};'.format(table, apply_id)
            db.execute(sql)
            db.commit()

if apply == "refuse":
    apply_id = form.getvalue("id")
    with sqlite3.connect(db_path) as db:
        sql = 'UPDATE {} SET status = 2 WHERE id = {};'.format(table, apply_id)
        db.execute(sql)
        db.commit()


print "Content-type: application/json"
print

print(json.JSONEncoder().encode(response))