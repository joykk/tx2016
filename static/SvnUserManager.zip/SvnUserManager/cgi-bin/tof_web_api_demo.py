#!/usr/bin/env python
# encoding: utf8
##########################################
# Author: curuwang
# Date:   2013-10-10
##########################################

import urllib2
import hashlib
import json
import sys
import binascii
import time
import random
from Crypto.Cipher import DES

tof_msg_url = { 
        'rtx' : 'http://api.tof.oa.com/api/v1/Message/SendRTX',
        'sms' : 'http://api.tof.oa.com/api/v1/Message/SendSMS',
        'wechat' : 'http://api.tof.oa.com/api/v1/Message/SendWeiXin'
        }
wechat_sender = "your weixin sender"
appkey = 'aa8569958c39441e8f97bf5d33796c41'
sys_id = '24924'

query_timeout = 5


def _pad(text, blocksize=8): 
    """ PKCS#5 Padding """
    pad = blocksize - (len(text) % blocksize)
    return text + pad * chr(pad)


def _des_signature(key, text):
    obj=DES.new(key, DES.MODE_CBC, key)
    ciph=obj.encrypt(_pad(text))
    return binascii.hexlify(ciph).upper()


def make_tof_auth_header():
    auth_header = {}
    auth_header['appkey'] = appkey
    auth_header['random'] = str(random.randint(1,1000000))
    auth_header['timestamp'] = str(int(time.time()))
    key = sys_id.ljust(8,'-')
    data = "random%stimestamp%s" % (auth_header['random'], auth_header['timestamp'])
    # caculate signature
    auth_header['signature'] = _des_signature(key, data)
    return auth_header


def encode_multipart_formdata(fields):
    """
    fields is a  (key, value) elements of dict for regular form fields.
    """
    BOUNDARY = "%s-%d" % (hashlib.md5(str(time.time())).hexdigest(), random.randint(1,1000000))
    CRLF = '\r\n'
    L = []
    for (key, value) in fields.items():
        L.append('--' + BOUNDARY)
        L.append('Content-Type: text/plain; charset=utf-8')
        L.append('Content-Disposition: form-data; name=%s' % key)
        L.append('')
        L.append(value)
    L.append('--' + BOUNDARY + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary="%s"' % BOUNDARY
    return content_type, body


def send_msg(msg_type, sender, receiver, msg, title=''):
    # weixin must be sent from registered sender in weixin.itil.com
    if msg_type == "wechat":
        sender = wechat_sender
    request_param = { 
            "MsgInfo"   :   msg,
            "Priority"  :   "1",
            "Receiver"  :   ";".join(receiver),
            "Sender"    :   sender,
            }
    if msg_type == "rtx":
        request_param["Title"] = title
    msg_url = tof_msg_url.get(msg_type)
    if msg_url is None:
        return None
    (content_type, request_data) = encode_multipart_formdata(request_param)
    auth_header = make_tof_auth_header()
    auth_header['Content-Type'] = content_type
    request = urllib2.Request(msg_url, request_data, auth_header)
    try:
        req = urllib2.urlopen(request, None, query_timeout)
    except urllib2.URLError as e:
        print "error querying server: %s" % e
        return None
    print "req ok"
    return req.read()


def get_staff_info_by_name(name):
    api_url = 'http://api.tof.oa.com/api/v1/Staff/Info?engName=%s' % name
    auth_header = make_tof_auth_header()
    request = urllib2.Request(api_url, None, auth_header)
    try:
        req = urllib2.urlopen(request, None, query_timeout)
    except urllib2.URLError as e:
        print "error querying server: %s" % e
        return e.read()
    print "req ok"
    return req.read()


def get_user_info(ticket, ip):
    api_url = 'http://api.tof.oa.com/api/v1/Passport/DecryptTicketWithClientIP?appkey={}&encryptedTicket={}&browseIP={}'.format(appkey, ticket, ip)
    auth_header = make_tof_auth_header()
    request = urllib2.Request(api_url, None, auth_header)
    try:
        req = urllib2.urlopen(request, None, query_timeout)
    except urllib2.URLError as e:
        print "error querying server: %s" % e
        return e.read()
    print "req ok"
    return req.read()



def map_msg_type(msg_code):
    msg_type_map = { "0" : "rtx", "1" : "sms", "2" : "wechat" }
    #code is type name
    if msg_code in msg_type_map.values():
        return msg_code
    else:
        return msg_type_map.get(msg_code)

if __name__ == "__main__":
    # if len(sys.argv) < 6:
    #     print >>sys.stderr, "Usage: %s [sender] [receiver] [title] [msgInfo] [msgType (0 => RTX信息 1 => 短信 2 => 微信)]" % sys.argv[0]
    #     sys.exit(1)
    # (sender, receiver, title, msginfo, msgtype_code) = sys.argv[1:]
    # # map msg type code to name
    # msgtype = map_msg_type(msgtype_code)
    # if msgtype is None:
    #     print >>sys.stderr, "ERROR: invalid msgtype '%s'" % msgtype_code
    #     sys.exit(1)
    #
    # # resp = get_staff_info_by_name('curuwang')
    # resp = send_msg(msgtype,sender,(receiver,), msginfo, title)
    # if resp is not None:
    #     resp = json.loads(resp)
    # if resp is None or resp['Ret'] != 0:
    #     errmsg = resp["ErrMsg"] if resp else ""
    #     print >>sys.stderr, "ERROR: send error: %s" % errmsg
    #     sys.exit(1)
    print make_tof_auth_header()
