#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bottle import Bottle, run, template, request, redirect, response, abort
import sqlite3
from utils import db_path, get_rtx_name
from config import config

app = Bottle()

url = "http://{}/cgi-bin/app.py/apply".format(config["ip"])
login_url = "http://passport.oa.com/modules/passport/signin.ashx?url={}".format(url)


def login():
    def deco(func):
        ticket = request.get_cookie("ticket")
        if ticket is None:
            return "<script>window.location =\"{}\"</script>".format(login_url)
        else:
            func()
    return deco


@login
@app.route("/apply")
def apply():
    try:
        ticket = request.query["ticket"]
    except KeyError:
        return "<script>window.location =\"{}\"</script>".format(login_url)
    rtx_name = get_rtx_name(ticket, request.remote_route)
    return rtx_name
    if rtx_name is None:
        return abort(500)
    return template("templates/apply.html", name=rtx_name)


@app.route("/apply_project", method="POST")
def apply_project():
    rtx_name = "pikezeng"
    project = request.forms.get('path')
    readable = request.forms.get('readable')
    writeable = request.forms.get('writeable')
    permission = ""
    if readable:
        permission += "r"
    if writeable:
        permission += "w"

    db = sqlite3.connect(db_path)
    sql = 'INSERT INTO project_apply (rtx_name, project, premission, status)' \
          ' VALUES ("{}", "{}", "{}", {});'.format(rtx_name, project, permission, 1)
    db.execute(sql)
    db.commit()
    db.close()
    return "OK"


@app.route("/apply_account", method="POST")
def apply_project():
    rtx_name = "pikezeng"
    password = request.forms.get("password")

    db = sqlite3.connect(db_path)
    sql = 'INSERT INTO account_apply (rtx_name, password, status) VALUES ("{}", "{}", {});'.format(rtx_name, password, 1)
    try:
        db.execute(sql)
        db.commit()
    except sqlite3.IntegrityError:
        return_code = 1
    db.close()
    return "OK"


@app.route("/manage")
def manage():
    return template("templates/manage.html")


@app.route("/manage/<apply>")
def manage_apply(apply):
    _res = {"content": []}
    if apply == "getProjectApplyList":
        with sqlite3.connect(db_path) as db:
            sql = 'SELECT * FROM project_apply WHERE STATUS = 1;'
            res = db.execute(sql)
            for row in res:
                row_dict = {"id": row[0], "apply_time": row[1], "rtx_name": row[2], "project": row[3], "premission": row[4]}
                _res["content"].append(row_dict)

        return _res
    if apply == "getAccountApplyList":
        with sqlite3.connect(db_path) as db:
            sql = 'SELECT * FROM account_apply WHERE STATUS = 1;'
            res = db.execute(sql)
            for row in res:
                row_dict = {"id": row[0], "apply_time": row[1], "rtx_name": row[2]}
                _res["content"].append(row_dict)


run(app, server="cgi")
