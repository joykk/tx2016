#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pickle
import os
import traceback
import time


class Session(dict):
    session_path = '/tmp/sessions'
    session_file = ''

    def __init__(self, sessionid):
        self.session_file = self.session_path + '/' + sessionid
        if not os.path.exists(self.session_path):
            os.makedirs(self.session_path)
        if not os.path.exists(self.session_file):
            with open(self.session_file, 'wb') as fp:
                pickle.dump({}, fp)
        else:
            #Load the session variables from file
            with open(self.session_file, 'rb') as fp:
                session_data = pickle.load(fp)
                self.update(session_data)

    def save(self):
        #save the session variables back to file
        session_data = dict(self.items())
        with open(self.session_file, 'wb') as fp:
            pickle.dump(session_data, fp)

    def delete(self):
        self.clear()
        try:
            os.remove(self.session_file)
        except:
            traceback.print_exc()
            pass

    def cleanup(self, timeout):
        now = time.time()
        for f in os.listdir(self.session_path):
            path = os.path.join(self.session_path, f)
            atime = os.stat(path).st_atime
            if now - atime > timeout :
                os.remove(path)