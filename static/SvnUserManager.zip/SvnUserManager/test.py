#!/usr/bin/env python
# -*- coding: utf-8 -*-
import threading

class BaseReq(object):
    def __init__(self, environ=None):
        self.environ = environ


class LocalReq(BaseReq):
    bind = BaseReq.__init__
    environ = threading.local()

req = LocalReq()
print req, req.environ, LocalReq.environ

req.bind({"type": "test"})
print req, req.environ, LocalReq.environ

